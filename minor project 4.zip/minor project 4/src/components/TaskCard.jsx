import { CalendarDays, Check, Circle, Pencil, Trash2 } from 'lucide-react'
import { formatDate, isOverdue } from '../utils/storage.js'

export default function TaskCard({ task, onToggle, onEdit, onDelete }) {
  const overdue = isOverdue(task)
  return (
    <article className={`task-card${task.completed ? ' is-completed' : ''}`}>
      <button className={`task-check${task.completed ? ' checked' : ''}`} onClick={() => onToggle(task.id)} aria-label={task.completed ? 'Mark task pending' : 'Mark task complete'}>
        {task.completed ? <Check size={14} strokeWidth={3} /> : <Circle size={19} strokeWidth={1.7} />}
      </button>
      <div className="task-copy">
        <h3>{task.title}</h3>
        {task.description && <p>{task.description}</p>}
        <div className="task-meta">
          {task.dueDate && <span className={`due-date${overdue ? ' overdue' : ''}`}><CalendarDays size={13} />{overdue ? 'Overdue · ' : 'Due '}{formatDate(task.dueDate, { month: 'short', day: 'numeric' })}</span>}
          <span className={`status-pill ${task.completed ? 'status-done' : 'status-pending'}`}>{task.completed ? 'Completed' : 'In progress'}</span>
        </div>
      </div>
      <div className="card-actions">
        <button className="icon-button small-icon" onClick={() => onEdit(task)} aria-label={`Edit ${task.title}`}><Pencil size={15} /></button>
        <button className="icon-button small-icon danger-hover" onClick={() => onDelete(task.id)} aria-label={`Delete ${task.title}`}><Trash2 size={15} /></button>
      </div>
    </article>
  )
}
