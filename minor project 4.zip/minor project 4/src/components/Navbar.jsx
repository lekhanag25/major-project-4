import { CalendarDays, Menu, UserRound } from 'lucide-react'
import { useLocation } from 'react-router-dom'

const titles = {
  '/': ['Good things start here', 'Here’s your productivity snapshot for today.'],
  '/tasks': ['To-Do List', 'Make space for what matters most.'],
  '/notes': ['Your Notes', 'All your thoughts, neatly in one place.'],
  '/settings': ['Settings', 'Manage your TaskFlow workspace and data.'],
}

export default function Navbar({ onMenuClick }) {
  const { pathname } = useLocation()
  const [title, subtitle] = titles[pathname] ?? titles['/']
  const today = new Intl.DateTimeFormat('en', { weekday: 'short', month: 'short', day: 'numeric' }).format(new Date())

  return (
    <header className="topbar">
      <button className="mobile-menu icon-button" onClick={onMenuClick} aria-label="Open navigation"><Menu size={20} /></button>
      <div className="page-heading">
        <h1>{title}</h1>
        <p>{subtitle}</p>
      </div>
      <div className="topbar-actions">
        <div className="date-chip"><CalendarDays size={16} /><span>{today}</span></div>
        <span className="topbar-divider" />
        <div className="profile-avatar" aria-label="Your profile"><UserRound size={18} /></div>
      </div>
    </header>
  )
}
