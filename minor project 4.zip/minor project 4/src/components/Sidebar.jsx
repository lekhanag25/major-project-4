import { NavLink } from 'react-router-dom'
import { LayoutDashboard, ListTodo, NotebookPen, Settings, Sparkles } from 'lucide-react'

const links = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/tasks', label: 'To-Do List', icon: ListTodo },
  { to: '/notes', label: 'Notes', icon: NotebookPen },
  { to: '/settings', label: 'Settings', icon: Settings },
]

export default function Sidebar() {
  return (
    <aside className="sidebar">
      <a className="brand" href="/" aria-label="TaskFlow home">
        <span className="brand-mark"><Sparkles size={21} strokeWidth={2.3} /></span>
        <span>taskflow<span className="brand-period">.</span></span>
      </a>
      <div className="sidebar-label">WORKSPACE</div>
      <nav className="side-nav" aria-label="Main navigation">
        {links.map(({ to, label, icon: Icon, end }) => (
          <NavLink key={to} to={to} end={end} className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}>
            <Icon size={19} strokeWidth={1.9} />
            <span>{label}</span>
          </NavLink>
        ))}
      </nav>
      <div className="sidebar-bottom">
        <div className="sidebar-tip">
          <span className="tip-icon"><Sparkles size={16} /></span>
          <p>A little progress each day adds up to big results.</p>
        </div>
        <div className="sidebar-version">MADE FOR YOUR NEXT BIG THING</div>
      </div>
    </aside>
  )
}
