import { ArrowUpRight } from 'lucide-react'

export default function StatCard({ label, value, detail, icon: Icon, tone = 'purple' }) {
  return (
    <article className="stat-card">
      <div className={`stat-icon ${tone}`}><Icon size={19} strokeWidth={2} /></div>
      <div className="stat-topline"><span>{label}</span><ArrowUpRight size={15} /></div>
      <div className="stat-value">{value}</div>
      <div className="stat-detail">{detail}</div>
    </article>
  )
}
