import { useEffect, useState } from 'react'
import { X } from 'lucide-react'

const categories = ['Personal', 'Study', 'Work', 'Ideas']

export default function NoteEditor({ note, onSave, onClose }) {
  const [title, setTitle] = useState(note?.title ?? '')
  const [content, setContent] = useState(note?.content ?? '')
  const [category, setCategory] = useState(note?.category ?? 'Personal')
  const [error, setError] = useState('')

  useEffect(() => {
    const onKeyDown = (event) => event.key === 'Escape' && onClose()
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [onClose])

  const handleSubmit = (event) => {
    event.preventDefault()
    if (!title.trim()) {
      setError('Give your note a title before saving.')
      return
    }
    onSave({ title: title.trim(), content: content.trim(), category })
  }

  return (
    <div className="modal-backdrop" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <section className="modal-panel note-editor" role="dialog" aria-modal="true" aria-labelledby="note-editor-title">
        <div className="modal-heading"><div><span className="eyebrow">YOUR NOTEBOOK</span><h2 id="note-editor-title">{note ? 'Edit note' : 'Create a note'}</h2></div><button className="icon-button" onClick={onClose} aria-label="Close"><X size={19} /></button></div>
        <form onSubmit={handleSubmit} className="form-stack">
          <label>Note title <span className="required">*</span><input autoFocus maxLength="100" value={title} onChange={(event) => { setTitle(event.target.value); setError('') }} placeholder="Give this note a name" /></label>
          <label>Category<select value={category} onChange={(event) => setCategory(event.target.value)}>{categories.map((item) => <option key={item} value={item}>{item}</option>)}</select></label>
          <label>What’s on your mind?<textarea className="note-content-input" rows="9" maxLength="5000" value={content} onChange={(event) => setContent(event.target.value)} placeholder="Start writing here..." /></label>
          {error && <p className="form-error" role="alert">{error}</p>}
          <div className="modal-actions"><button type="button" className="button button-quiet" onClick={onClose}>Cancel</button><button type="submit" className="button button-primary">{note ? 'Save changes' : 'Save note'}</button></div>
        </form>
      </section>
    </div>
  )
}
