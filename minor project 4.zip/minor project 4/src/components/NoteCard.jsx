import { Clock3, Pencil, Trash2 } from 'lucide-react'
import { formatDate } from '../utils/storage.js'

export default function NoteCard({ note, onEdit, onDelete }) {
  return (
    <article className="note-card">
      <div className="note-card-top"><span className={`category-tag category-${note.category.toLowerCase()}`}>{note.category}</span><div className="card-actions"><button className="icon-button small-icon" onClick={() => onEdit(note)} aria-label={`Edit ${note.title}`}><Pencil size={15} /></button><button className="icon-button small-icon danger-hover" onClick={() => onDelete(note.id)} aria-label={`Delete ${note.title}`}><Trash2 size={15} /></button></div></div>
      <button className="note-card-content" onClick={() => onEdit(note)} aria-label={`Open note ${note.title}`}>
        <h3>{note.title}</h3><p>{note.content || 'No content yet.'}</p>
      </button>
      <div className="note-footer"><span><Clock3 size={13} />Updated {formatDate(note.updatedAt, { month: 'short', day: 'numeric' })}</span><span>Created {formatDate(note.createdAt, { month: 'short', day: 'numeric' })}</span></div>
    </article>
  )
}
