import { useEffect, useState } from 'react'
import { X } from 'lucide-react'

export default function TaskForm({ task, onSave, onClose }) {
  const [title, setTitle] = useState(task?.title ?? '')
  const [description, setDescription] = useState(task?.description ?? '')
  const [dueDate, setDueDate] = useState(task?.dueDate ?? '')
  const [error, setError] = useState('')

  useEffect(() => {
    const onKeyDown = (event) => event.key === 'Escape' && onClose()
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [onClose])

  const handleSubmit = (event) => {
    event.preventDefault()
    if (!title.trim()) {
      setError('A task title is required.')
      return
    }
    onSave({ title: title.trim(), description: description.trim(), dueDate })
  }

  return (
    <div className="modal-backdrop" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <section className="modal-panel" role="dialog" aria-modal="true" aria-labelledby="task-form-title">
        <div className="modal-heading"><div><span className="eyebrow">TASK DETAILS</span><h2 id="task-form-title">{task ? 'Edit task' : 'Create a task'}</h2></div><button className="icon-button" onClick={onClose} aria-label="Close"><X size={19} /></button></div>
        <form onSubmit={handleSubmit} className="form-stack">
          <label>Task title <span className="required">*</span><input autoFocus maxLength="100" value={title} onChange={(event) => { setTitle(event.target.value); setError('') }} placeholder="e.g. Finish project proposal" /></label>
          <label>Description <span className="optional">Optional</span><textarea rows="3" maxLength="500" value={description} onChange={(event) => setDescription(event.target.value)} placeholder="Add a little more detail..." /></label>
          <label>Due date <span className="optional">Optional</span><input type="date" value={dueDate} onChange={(event) => setDueDate(event.target.value)} /></label>
          {error && <p className="form-error" role="alert">{error}</p>}
          <div className="modal-actions"><button type="button" className="button button-quiet" onClick={onClose}>Cancel</button><button type="submit" className="button button-primary">{task ? 'Save changes' : 'Add task'}</button></div>
        </form>
      </section>
    </div>
  )
}
