import { useEffect, useState } from 'react'
import { Route, Routes } from 'react-router-dom'
import Sidebar from './components/Sidebar.jsx'
import Navbar from './components/Navbar.jsx'
import Dashboard from './pages/Dashboard.jsx'
import TodoPage from './pages/TodoPage.jsx'
import NotesPage from './pages/NotesPage.jsx'
import SettingsPage from './pages/SettingsPage.jsx'
import { createId, loadItems, noteStorageKey, saveItems, taskStorageKey } from './utils/storage.js'

export default function App() {
  const [tasks, setTasks] = useState(() => loadItems(taskStorageKey))
  const [notes, setNotes] = useState(() => loadItems(noteStorageKey))
  const [toast, setToast] = useState('')
  const [mobileNavOpen, setMobileNavOpen] = useState(false)

  useEffect(() => saveItems(taskStorageKey, tasks), [tasks])
  useEffect(() => saveItems(noteStorageKey, notes), [notes])
  useEffect(() => {
    if (!toast) return undefined
    const timer = window.setTimeout(() => setToast(''), 2800)
    return () => window.clearTimeout(timer)
  }, [toast])

  const saveTask = (values, existingTask = null) => {
    const now = new Date().toISOString()
    if (existingTask) {
      setTasks((current) => current.map((task) => task.id === existingTask.id ? { ...task, ...values, updatedAt: now } : task))
      setToast('Task updated successfully.')
    } else {
      setTasks((current) => [{ ...values, id: createId(), completed: false, createdAt: now, updatedAt: now }, ...current])
      setToast('Task added successfully.')
    }
  }

  const toggleTask = (taskId) => {
    setTasks((current) => current.map((task) => task.id === taskId ? { ...task, completed: !task.completed, updatedAt: new Date().toISOString() } : task))
  }

  const deleteTask = (taskId) => {
    const task = tasks.find((item) => item.id === taskId)
    if (task && window.confirm(`Delete "${task.title}"? This cannot be undone.`)) {
      setTasks((current) => current.filter((item) => item.id !== taskId))
      setToast('Task deleted.')
    }
  }

  const saveNote = (values, existingNote = null) => {
    const now = new Date().toISOString()
    if (existingNote) {
      setNotes((current) => current.map((note) => note.id === existingNote.id ? { ...note, ...values, updatedAt: now } : note))
      setToast('Note updated successfully.')
    } else {
      setNotes((current) => [{ ...values, id: createId(), createdAt: now, updatedAt: now }, ...current])
      setToast('Note saved successfully.')
    }
  }

  const deleteNote = (noteId) => {
    const note = notes.find((item) => item.id === noteId)
    if (note && window.confirm(`Delete "${note.title}"? This cannot be undone.`)) {
      setNotes((current) => current.filter((item) => item.id !== noteId))
      setToast('Note deleted.')
    }
  }

  const clearData = () => {
    setTasks([])
    setNotes([])
    setToast('Workspace data cleared.')
  }

  const sharedProps = { tasks, notes, onSaveTask: saveTask, onToggleTask: toggleTask, onDeleteTask: deleteTask, onSaveNote: saveNote, onDeleteNote: deleteNote }

  return (
    <div className="app-shell">
      {mobileNavOpen && <button className="mobile-nav-backdrop" aria-label="Close navigation" onClick={() => setMobileNavOpen(false)} />}
      <div className={`sidebar-wrap${mobileNavOpen ? ' mobile-open' : ''}`}><Sidebar /></div>
      <main className="main-area">
        <Navbar onMenuClick={() => setMobileNavOpen(true)} />
        <div className="route-content" onClick={() => mobileNavOpen && setMobileNavOpen(false)}>
          <Routes>
            <Route path="/" element={<Dashboard {...sharedProps} />} />
            <Route path="/tasks" element={<TodoPage tasks={tasks} onSaveTask={saveTask} onToggleTask={toggleTask} onDeleteTask={deleteTask} />} />
            <Route path="/notes" element={<NotesPage notes={notes} onSaveNote={saveNote} onDeleteNote={deleteNote} />} />
            <Route path="/settings" element={<SettingsPage tasks={tasks} notes={notes} onClearData={clearData} />} />
            <Route path="*" element={<Dashboard {...sharedProps} />} />
          </Routes>
          <footer className="app-footer"><span>© {new Date().getFullYear()} TaskFlow</span><span>Small steps, meaningful progress.</span></footer>
        </div>
      </main>
      {toast && <div className="toast-message" role="status"><span className="toast-check">✓</span>{toast}</div>}
    </div>
  )
}
