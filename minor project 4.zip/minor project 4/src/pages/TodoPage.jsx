import { useMemo, useState } from 'react'
import { CheckCheck, ClipboardList, ListFilter, Plus, Search } from 'lucide-react'
import TaskCard from '../components/TaskCard.jsx'
import TaskForm from '../components/TaskForm.jsx'

const filters = ['All', 'Pending', 'Completed']

export default function TodoPage({ tasks, onSaveTask, onToggleTask, onDeleteTask }) {
  const [filter, setFilter] = useState('All')
  const [sortBy, setSortBy] = useState('newest')
  const [search, setSearch] = useState('')
  const [editingTask, setEditingTask] = useState(null)
  const [isCreating, setIsCreating] = useState(false)

  const visibleTasks = useMemo(() => {
    let result = tasks.filter((task) => {
      const matchesFilter = filter === 'All' || (filter === 'Completed' ? task.completed : !task.completed)
      return matchesFilter && task.title.toLowerCase().includes(search.trim().toLowerCase())
    })
    result = [...result].sort((a, b) => {
      if (sortBy === 'dueDate') {
        if (!a.dueDate) return 1
        if (!b.dueDate) return -1
        return new Date(a.dueDate) - new Date(b.dueDate)
      }
      return new Date(b.createdAt) - new Date(a.createdAt)
    })
    return result
  }, [tasks, filter, search, sortBy])

  const saveTask = (values) => {
    onSaveTask(values, editingTask)
    setIsCreating(false)
    setEditingTask(null)
  }

  return (
    <div className="page-content">
      <div className="page-toolbar">
        <div className="toolbar-count"><span className="toolbar-count-icon"><CheckCheck size={17} /></span><span><strong>{tasks.length} {tasks.length === 1 ? 'task' : 'tasks'}</strong><small>{tasks.filter((task) => !task.completed).length} still in progress</small></span></div>
        <button className="button button-primary" onClick={() => setIsCreating(true)}><Plus size={17} /> New task</button>
      </div>
      <section className="panel task-workspace">
        <div className="filter-row">
          <div className="segmented-control" role="tablist" aria-label="Filter tasks">{filters.map((item) => <button key={item} role="tab" aria-selected={filter === item} className={filter === item ? 'selected' : ''} onClick={() => setFilter(item)}>{item}<span>{item === 'All' ? tasks.length : tasks.filter((task) => item === 'Completed' ? task.completed : !task.completed).length}</span></button>)}</div>
          <div className="task-tools"><label className="search-field"><Search size={16} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search tasks..." aria-label="Search tasks by title" />{search && <button type="button" className="clear-search" aria-label="Clear search" onClick={() => setSearch('')}>×</button>}</label><label className="sort-select"><ListFilter size={15} /><select aria-label="Sort tasks" value={sortBy} onChange={(event) => setSortBy(event.target.value)}><option value="newest">Newest first</option><option value="dueDate">Due date</option></select></label></div>
        </div>
        <div className="task-list">
          {visibleTasks.map((task) => <TaskCard key={task.id} task={task} onToggle={onToggleTask} onEdit={setEditingTask} onDelete={onDeleteTask} />)}
          {!visibleTasks.length && <div className="empty-state"><span className="empty-illustration"><ClipboardList size={30} /></span><h3>{tasks.length ? 'No tasks match that view' : 'Your task list is a blank canvas'}</h3><p>{tasks.length ? 'Try a different search or filter to find what you need.' : 'Add your first task and start making progress.'}</p>{!tasks.length && <button className="button button-primary" onClick={() => setIsCreating(true)}><Plus size={16} /> Create your first task</button>}</div>}
        </div>
      </section>
      {(isCreating || editingTask) && <TaskForm task={editingTask} onSave={saveTask} onClose={() => { setIsCreating(false); setEditingTask(null) }} />}
    </div>
  )
}
