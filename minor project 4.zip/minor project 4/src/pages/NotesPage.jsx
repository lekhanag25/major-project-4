import { useMemo, useState } from 'react'
import { FileText, Plus, Search } from 'lucide-react'
import NoteCard from '../components/NoteCard.jsx'
import NoteEditor from '../components/NoteEditor.jsx'

const categories = ['All', 'Personal', 'Study', 'Work', 'Ideas']

export default function NotesPage({ notes, onSaveNote, onDeleteNote }) {
  const [category, setCategory] = useState('All')
  const [search, setSearch] = useState('')
  const [editingNote, setEditingNote] = useState(null)
  const [isCreating, setIsCreating] = useState(false)

  const visibleNotes = useMemo(() => notes
    .filter((note) => category === 'All' || note.category === category)
    .filter((note) => `${note.title} ${note.content}`.toLowerCase().includes(search.trim().toLowerCase()))
    .sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt)), [notes, category, search])

  const saveNote = (values) => {
    onSaveNote(values, editingNote)
    setIsCreating(false)
    setEditingNote(null)
  }

  return (
    <div className="page-content">
      <div className="page-toolbar">
        <div className="toolbar-count"><span className="toolbar-count-icon notes-icon"><FileText size={17} /></span><span><strong>{notes.length} {notes.length === 1 ? 'note' : 'notes'}</strong><small>Your ideas, always within reach</small></span></div>
        <button className="button button-primary" onClick={() => setIsCreating(true)}><Plus size={17} /> New note</button>
      </div>
      <section className="notes-workspace">
        <div className="notes-toolbar">
          <div className="category-filters" aria-label="Filter notes by category">{categories.map((item) => <button key={item} className={category === item ? 'active' : ''} onClick={() => setCategory(item)}>{item}</button>)}</div>
          <label className="search-field notes-search"><Search size={16} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search your notes..." aria-label="Search notes by title or content" />{search && <button type="button" className="clear-search" aria-label="Clear search" onClick={() => setSearch('')}>×</button>}</label>
        </div>
        {visibleNotes.length ? <div className="notes-grid">{visibleNotes.map((note) => <NoteCard key={note.id} note={note} onEdit={setEditingNote} onDelete={onDeleteNote} />)}</div> : <div className="panel empty-state notes-empty"><span className="empty-illustration note-empty-icon"><FileText size={29} /></span><h3>{notes.length ? 'No notes found' : 'A space for all your ideas'}</h3><p>{notes.length ? 'Try another category or search term.' : 'Save a thought, a class note, or a spark of inspiration.'}</p>{!notes.length && <button className="button button-primary" onClick={() => setIsCreating(true)}><Plus size={16} /> Write your first note</button>}</div>}
      </section>
      {(isCreating || editingNote) && <NoteEditor note={editingNote} onSave={saveNote} onClose={() => { setIsCreating(false); setEditingNote(null) }} />}
    </div>
  )
}
