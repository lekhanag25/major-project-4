import { useMemo, useState } from 'react'
import { ArrowRight, CheckCheck, CircleDot, ClipboardList, FileText, Plus, Sparkles } from 'lucide-react'
import { Link } from 'react-router-dom'
import StatCard from '../components/StatCard.jsx'
import TaskCard from '../components/TaskCard.jsx'
import NoteCard from '../components/NoteCard.jsx'
import TaskForm from '../components/TaskForm.jsx'
import NoteEditor from '../components/NoteEditor.jsx'

export default function Dashboard({ tasks, notes, onSaveTask, onToggleTask, onDeleteTask, onSaveNote, onDeleteNote }) {
  const [showTaskForm, setShowTaskForm] = useState(false)
  const [showNoteEditor, setShowNoteEditor] = useState(false)
  const completed = tasks.filter((task) => task.completed).length
  const pending = tasks.length - completed
  const progress = tasks.length ? Math.round((completed / tasks.length) * 100) : 0
  const recentTasks = useMemo(() => [...tasks].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 3), [tasks])
  const recentNotes = useMemo(() => [...notes].sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt)).slice(0, 2), [notes])

  const saveTask = (values) => {
    onSaveTask(values, showTaskForm === true ? null : showTaskForm)
    setShowTaskForm(false)
  }
  const saveNote = (values) => {
    onSaveNote(values, showNoteEditor === true ? null : showNoteEditor)
    setShowNoteEditor(false)
  }

  return (
    <div className="page-content dashboard-page">
      <section className="welcome-banner">
        <div className="welcome-copy"><span className="welcome-kicker"><Sparkles size={14} /> YOUR SPACE, YOUR PACE</span><h2>Make today <em>count.</em></h2><p>A clear mind starts with a clear plan. You’ve got this.</p><div className="welcome-buttons"><button className="button button-light" onClick={() => setShowTaskForm(true)}><Plus size={17} /> Add a task</button><button className="button button-outline-light" onClick={() => setShowNoteEditor(true)}><Plus size={17} /> Write a note</button></div></div>
        <div className="welcome-art" aria-hidden="true"><div className="art-orbit orbit-one" /><div className="art-orbit orbit-two" /><div className="art-check"><CheckCheck size={47} strokeWidth={1.5} /></div><span className="art-spark spark-one">✦</span><span className="art-spark spark-two">✧</span><div className="art-mini-card"><span>YOUR MOMENTUM</span><strong>{progress}%</strong><div className="mini-bar"><i style={{ width: `${progress}%` }} /></div></div></div>
      </section>

      <section className="stats-grid" aria-label="Productivity statistics">
        <StatCard label="Total tasks" value={tasks.length} detail="Tasks in your workspace" icon={ClipboardList} tone="purple" />
        <StatCard label="Completed" value={completed} detail="One step at a time" icon={CheckCheck} tone="green" />
        <StatCard label="Pending" value={pending} detail="Ready when you are" icon={CircleDot} tone="orange" />
        <StatCard label="Notes" value={notes.length} detail="Ideas worth keeping" icon={FileText} tone="blue" />
      </section>

      <section className="progress-panel panel">
        <div><div className="panel-title-row"><div><h2>Task progress</h2><p>Your consistency is what counts.</p></div><span className="progress-number">{progress}%</span></div><div className="progress-track"><span style={{ width: `${progress}%` }} /></div><div className="progress-labels"><span>{completed} completed</span><span>{pending} to go</span></div></div>
        <div className="progress-illustration"><div className="progress-ring"><span>{progress}<small>%</small></span></div><span className="ring-caption">KEEP IT UP</span></div>
      </section>

      <div className="dashboard-columns">
        <section className="panel list-panel">
          <div className="section-heading"><div><span className="eyebrow">STAY ON TRACK</span><h2>Recent tasks</h2></div><Link to="/tasks" className="text-link">View all <ArrowRight size={15} /></Link></div>
          {recentTasks.length ? <div className="dashboard-task-list">{recentTasks.map((task) => <TaskCard key={task.id} task={task} onToggle={onToggleTask} onEdit={() => setShowTaskForm(task)} onDelete={onDeleteTask} />)}</div> : <div className="compact-empty"><span><ClipboardList size={20} /></span><p>No tasks just yet. Add one to get started.</p></div>}
        </section>
        <section className="panel list-panel recent-notes-panel">
          <div className="section-heading"><div><span className="eyebrow">CAPTURE A THOUGHT</span><h2>Recent notes</h2></div><Link to="/notes" className="text-link">View all <ArrowRight size={15} /></Link></div>
          {recentNotes.length ? <div className="dashboard-note-list">{recentNotes.map((note) => <NoteCard key={note.id} note={note} onEdit={() => setShowNoteEditor(note)} onDelete={onDeleteNote} />)}</div> : <div className="compact-empty"><span><FileText size={20} /></span><p>Your next great idea can start here.</p><button className="inline-link" onClick={() => setShowNoteEditor(true)}>Create a note <ArrowRight size={14} /></button></div>}
        </section>
      </div>
      {showTaskForm && <TaskForm task={showTaskForm === true ? null : showTaskForm} onSave={saveTask} onClose={() => setShowTaskForm(false)} />}
      {showNoteEditor && <NoteEditor note={showNoteEditor === true ? null : showNoteEditor} onSave={saveNote} onClose={() => setShowNoteEditor(false)} />}
    </div>
  )
}
