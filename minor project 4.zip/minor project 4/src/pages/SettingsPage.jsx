import { useRef } from 'react'
import { AlertTriangle, Download, HardDrive, ShieldCheck, Trash2 } from 'lucide-react'

export default function SettingsPage({ tasks, notes, onClearData }) {
  const downloadLink = useRef(null)

  const exportData = () => {
    const backup = { exportedAt: new Date().toISOString(), tasks, notes }
    const file = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(file)
    const link = downloadLink.current
    link.href = url
    link.download = `taskflow-backup-${new Date().toISOString().slice(0, 10)}.json`
    link.click()
    window.setTimeout(() => URL.revokeObjectURL(url), 1000)
  }

  const clearData = () => {
    if (window.confirm('Delete all tasks and notes from this browser? This action cannot be undone.')) onClearData()
  }

  return (
    <div className="page-content settings-page">
      <section className="settings-intro"><div className="settings-intro-icon"><ShieldCheck size={22} /></div><div><h2>Your workspace, your data</h2><p>TaskFlow stores everything locally in this browser. Your personal notes and tasks are never sent to a server.</p></div></section>
      <section className="panel settings-panel">
        <div className="settings-section-heading"><span className="settings-icon"><HardDrive size={18} /></span><div><h3>Workspace data</h3><p>Review and manage your saved information.</p></div></div>
        <div className="settings-info-row"><div><strong>Stored in this browser</strong><span>{tasks.length} tasks · {notes.length} notes</span></div><span className="local-badge"><i /> Local storage</span></div>
        <div className="settings-action-row"><div><strong>Export a backup</strong><span>Download your tasks and notes as a JSON file.</span></div><button className="button button-secondary" onClick={exportData}><Download size={16} /> Export data</button><a ref={downloadLink} className="visually-hidden" aria-hidden="true" /></div>
      </section>
      <section className="panel danger-panel">
        <div className="settings-section-heading"><span className="settings-icon danger-settings-icon"><AlertTriangle size={18} /></span><div><h3>Clear workspace</h3><p>Remove all saved tasks and notes from this browser.</p></div></div>
        <div className="settings-action-row"><div><strong>Delete all workspace data</strong><span>This cannot be undone. Export a backup first if you want to keep your data.</span></div><button className="button button-danger-outline" onClick={clearData}><Trash2 size={15} /> Clear all data</button></div>
      </section>
      <p className="settings-footnote">Changes to tasks and notes are saved automatically as you work.</p>
    </div>
  )
}
