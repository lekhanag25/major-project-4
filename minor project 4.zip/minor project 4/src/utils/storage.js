const TASKS_KEY = 'taskflow-tasks'
const NOTES_KEY = 'taskflow-notes'

export const loadItems = (key) => {
  try {
    const savedItems = localStorage.getItem(key)
    return savedItems ? JSON.parse(savedItems) : []
  } catch (error) {
    console.error(`Unable to load saved data for "${key}".`, error)
    return []
  }
}

export const saveItems = (key, items) => {
  try {
    localStorage.setItem(key, JSON.stringify(items))
  } catch (error) {
    console.error(`Unable to save data for "${key}".`, error)
  }
}

export const taskStorageKey = TASKS_KEY
export const noteStorageKey = NOTES_KEY

export const formatDate = (date, options = { month: 'short', day: 'numeric', year: 'numeric' }) => {
  if (!date) return 'No date'
  return new Intl.DateTimeFormat('en', options).format(new Date(date))
}

export const isOverdue = (task) => {
  if (!task.dueDate || task.completed) return false
  const due = new Date(`${task.dueDate}T23:59:59`)
  return due < new Date()
}

export const createId = () => (
  globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(16).slice(2)}`
)
