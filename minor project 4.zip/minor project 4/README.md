# TaskFlow – To-Do App & Notes App

TaskFlow is a responsive productivity dashboard for organizing everyday tasks and keeping useful notes together. It is built as a college Web Development Week 04 minor project with React and browser Local Storage—there is no backend or database.

## Features

- Dashboard with total, completed, and pending task counts; note count; completion progress; and recently updated items.
- Create, edit, complete, search, sort, and delete tasks, with optional descriptions and due dates.
- Overdue task indicators and All, Pending, and Completed filters.
- Create, edit, search, categorize, and delete notes, with created and last-updated dates.
- Category filters for Personal, Study, Work, and Ideas.
- Automatic persistence in Local Storage, including restore after refresh.
- Responsive sidebar navigation and layouts for desktop, tablet, and mobile.
- Confirmation dialogs, inline validation, empty states, and success messages.
- Settings to export a JSON backup or clear all saved workspace data.

## Technologies

- React 18, JSX, and JavaScript ES6+
- Vite
- HTML5 and CSS3
- React Hooks (`useState`, `useEffect`, and `useMemo`)
- React Router
- Lucide React icons
- Browser Local Storage

## React concepts demonstrated

The source uses functional components, JSX, props, state, effects, event handlers, conditional rendering, list rendering with `.map()`, reusable components, arrow functions, template literals, destructuring, spread syntax, `const`/`let`, and array methods including `.map()`, `.filter()`, `.find()`, and `.sort()`. Shared data flows from `App.jsx` to page components through props.

## Requirements

- Node.js 18 or newer (Node.js 20+ recommended)
- npm
- Visual Studio Code (recommended)

## Install and run locally

Open this folder in VS Code, then open **Terminal → New Terminal** and run:

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (usually `http://localhost:5173`) in your browser.

Useful commands:

```bash
npm run dev       # Start the development server
npm run build     # Create an optimized production build in dist/
npm run preview   # Preview the production build locally
```

## Screenshots

Add screenshots of the Dashboard, To-Do List, Notes, and mobile layouts here before submitting:

```text
docs/screenshots/dashboard.png
docs/screenshots/tasks.png
docs/screenshots/notes.png
docs/screenshots/mobile.png
```

You can then embed them in this section, for example:

```markdown
![TaskFlow dashboard](docs/screenshots/dashboard.png)
```

## GitHub repository setup

Create a new, empty repository on GitHub. Before initializing Git, make sure this project folder is not inside another repository: run `git rev-parse --show-toplevel` from the project terminal. If that command reports a parent folder rather than this project folder, place/copy the TaskFlow folder in a standalone location (for example, `C:\Users\YOUR-NAME\Documents\TaskFlow`) and open that standalone folder in VS Code. This prevents unrelated files from being included in your project repository.

From the standalone TaskFlow folder, run:

```bash
git init
git add .
git commit -m "Build TaskFlow productivity app"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Replace `YOUR-USERNAME` and `YOUR-REPOSITORY` with your GitHub details. The `.gitignore` file excludes generated dependencies and build output.

## Data and privacy

Tasks and notes are saved only in the browser's Local Storage. Data is specific to the browser and device and is not synchronized or backed up automatically. Use **Settings → Export data** to download a JSON backup before clearing browser data.
